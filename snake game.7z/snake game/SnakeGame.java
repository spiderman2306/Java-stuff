import java.awt.Point;
import java.util.Random;
import java.util.Scanner;

public class SnakeGame {
    private final int GRID_SIZE = 10;
    
    private MyArrayList<Point> snake;
    
    private Point food;
    
    private char direction;
    
    private int score;
    
    private boolean gameOver;
    
    private Random rand = new Random();
    
    private Scanner scanner = new Scanner(System.in);

    public SnakeGame(){
        startGame();
    }

    public void startGame() {
        snake = new MyArrayList<>();
        score = 0;
        direction = 'W';
        gameOver = false;

        //start game at the center of the grid
        snake.add(0, new Point(GRID_SIZE/2, GRID_SIZE/2));

        placeFood();
    }

    private void placeFood(){
        while (true){
            int x = rand.nextInt(GRID_SIZE);
            int y = rand.nextInt(GRID_SIZE);
            Point p = new Point(x, y);
            if (!snake.contains(p)){
                food = p;
                break;
            }
        }
    }

    public void play(){
        while (!gameOver){
            printGrid();
            System.out.print("Enter your dirextion (WASD): ");
            String input = scanner.nextLine().toUpperCase();
            if (!input.isEmpty()) {
                char c = input.charAt(0);
                if ("WASD".indexOf(c) >= 0) {
                    direction = c;
                }
            }
            move();
        }
        System.out.println("you either hit a wall or bit yourseld noob, your size " +snake.getSize()+ ",final Score: " +score);
    }

    private void move() {
        Point head = snake.get(0);
        Point newHead = new Point(head.x, head.y);

        switch (direction) {
            case 'W': newHead.y--; break;
            case 'S': newHead.y++; break;
            case 'A': newHead.x--; break;
            case 'D': newHead.x++; break;
        }

        // when it hits the wall, it's chaii
        if (newHead.x < 0|| newHead.x >= GRID_SIZE ||
            newHead.y < 0 || newHead.y >= GRID_SIZE ){
                gameOver = true;
                return;
            }
       
        // should the snake devour it's big beautiful body
        if (snake.contains(newHead)) {
            gameOver = true;
            return;
        }

       
        snake.add(0, newHead);

        //eating the food that pops up randomly on the map
        if (newHead.equals(food)){
            score++;
            placeFood();
        } else{
            // prevent the snake from growing by moving across thegrid
            snake.remove(snake.getSize() - 1);
        }
    }

    private void printGrid() {
        for (int y = 0; y < GRID_SIZE; y++) {
            for (int x = 0; x < GRID_SIZE; x++) {
                Point p = new Point(x, y);
                if (p.equals(snake.get(0))) {
                    System.out.print("H ");
                } else if (snake.contains(p)) {
                    System.out.print("b ");
                } else if (p.equals(food)) {
                    System.out.print("* ");
                } else {
                    System.out.print(". ");
                }
            }
            System.out.println();
        }
        System.out.println("Score: " + score);
    }
}

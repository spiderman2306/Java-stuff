import java.util.Scanner;

public class SnakeTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean playAgain;

        do {
            SnakeGame game = new SnakeGame();
            game.play();
            System.out.print("do you want to play again? (Y/N): ");
            playAgain = sc.nextLine().equalsIgnoreCase("Y");
        } while (playAgain);

        sc.close();
    }
}
